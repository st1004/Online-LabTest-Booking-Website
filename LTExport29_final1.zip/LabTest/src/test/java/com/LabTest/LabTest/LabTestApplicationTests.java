package com.LabTest.LabTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
