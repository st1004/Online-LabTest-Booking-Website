package com.LabTest.LabTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabTestApplication.class, args);
	}

}
